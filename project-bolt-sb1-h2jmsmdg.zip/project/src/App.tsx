import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Link, Routes } from 'react-router-dom';
import axios from 'axios';
import { MessageCircle, Send, Users, MessageSquare, Menu, X, LogOut } from 'lucide-react';

const platforms = [
    { name: 'Telegram', icon: <Send className="w-5 h-5" />, url: 'https://web.telegram.org/' },
    { name: 'WhatsApp', icon: <MessageCircle className="w-5 h-5" />, url: 'https://web.whatsapp.com/' },
    { name: 'Messenger', icon: <MessageSquare className="w-5 h-5" />, url: 'https://www.messenger.com/' },
    { name: 'Discord', icon: <Users className="w-5 h-5" />, url: 'https://discord.com/app' }
];

const Home = () => (
  <div className="flex flex-col items-center justify-center h-full bg-gradient-to-br from-blue-50 to-indigo-50 p-8">
    <h2 className="text-3xl font-bold text-gray-800 mb-6">Welcome to MultiMessenger</h2>
    <p className="text-gray-600 text-center max-w-md">
      Select a messaging platform from the sidebar to get started. All your favorite messaging apps in one place.
    </p>
  </div>
);

const MessengerView = ({ url }: { url: string }) => {
    return (
        <iframe src={url} title="Messenger View" className="w-full h-screen border-none" />
    );
};

const App = () => {
    const [user, setUser] = useState(null);
    const [isSidebarOpen, setIsSidebarOpen] = useState(true);

    useEffect(() => {
        axios.get('/auth/user', { withCredentials: true })
            .then(res => setUser(res.data))
            .catch(() => setUser(null));
    }, []);

    const handleLogout = () => {
        axios.get('/auth/logout', { withCredentials: true })
            .then(() => setUser(null));
    };

    const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

    return (
        <Router>
            <div className="flex h-screen bg-gray-100">
                {/* Mobile menu button */}
                <button 
                    onClick={toggleSidebar}
                    className="lg:hidden fixed top-4 left-4 z-50 p-2 rounded-md bg-white shadow-md"
                >
                    {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>

                {/* Sidebar */}
                <aside className={`
                    fixed lg:static inset-y-0 left-0 z-40
                    transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
                    lg:translate-x-0 transition-transform duration-300 ease-in-out
                    w-64 bg-white shadow-lg
                    flex flex-col
                `}>
                    <div className="p-6">
                        <h2 className="text-2xl font-bold text-gray-800">MultiMessenger</h2>
                    </div>

                    {/* User section */}
                    <div className="px-6 py-4 border-t border-b border-gray-200">
                        {user ? (
                            <div className="flex items-center justify-between">
                                <div className="flex items-center space-x-3">
                                    <img 
                                        src={user.photoURL || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=48&h=48&q=80'} 
                                        alt="Profile" 
                                        className="w-8 h-8 rounded-full"
                                    />
                                    <span className="text-sm font-medium text-gray-700">{user.displayName}</span>
                                </div>
                                <button 
                                    onClick={handleLogout}
                                    className="p-2 text-gray-500 hover:text-gray-700"
                                >
                                    <LogOut className="w-5 h-5" />
                                </button>
                            </div>
                        ) : (
                            <a 
                                href="/auth/google"
                                className="flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                            >
                                Login with Google
                            </a>
                        )}
                    </div>

                    {/* Navigation */}
                    <nav className="flex-1 px-4 py-4">
                        <ul className="space-y-2">
                            {platforms.map((platform) => (
                                <li key={platform.name}>
                                    <Link
                                        to={`/${platform.name.toLowerCase()}`}
                                        className="flex items-center space-x-3 px-4 py-2 text-gray-700 rounded-md hover:bg-gray-100 transition-colors"
                                        onClick={() => window.innerWidth < 1024 && setIsSidebarOpen(false)}
                                    >
                                        {platform.icon}
                                        <span>{platform.name}</span>
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </nav>
                </aside>

                {/* Main content */}
                <main className="flex-1 overflow-hidden">
                    <Routes>
                        <Route path="/" element={<Home />} />
                        {platforms.map((platform) => (
                            <Route 
                                key={platform.name} 
                                path={`/${platform.name.toLowerCase()}`} 
                                element={<MessengerView url={platform.url} />} 
                            />
                        ))}
                    </Routes>
                </main>
            </div>
        </Router>
    );
};

export default App;